#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main () {

    printf("checkpoint 1");
    sleep(1);

    printf("checkpoint 2");
    sleep(1);

    printf("checkpoint 3");
    sleep(1);

    printf("checkpoint 4");
    sleep(1);

    printf("checkpoint 5");
    sleep(1);

    printf("checkpoint 6");
    sleep(1);

    printf("checkpoint 7");
    sleep(1);

    printf("checkpoint 8");
    sleep(1);

    printf("checkpoint 9");
    sleep(1);

    printf("checkpoint 10");
    sleep(1);
    
    printf("\n");

    exit(0);
}